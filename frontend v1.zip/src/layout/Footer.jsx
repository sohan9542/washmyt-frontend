import React from "react";

const Footer = () => {
  return (
    <div className=" py-4 w-full text-center">
      Copyright © 2023 CarOrder.co - All Rights Reserved
    </div>
  );
};

export default Footer;
